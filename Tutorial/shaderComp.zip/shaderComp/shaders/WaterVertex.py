from ..core.Shader import *
from ..core import ShaderType
##
# @authors Romain GUYOT de la HARDROUYERE
# @authors Matthieu BOURNAT
# @authors Antoine CHESNEAU
# @package shaderComp.shaders.WaterVertex
# @brief This shader will create a water effect on a water plane
# @version 1.0
# @date 2014-01-07
# @shadertype Vertex Shader
# @details This is the vertex-part of the shader water
# @details __Input variables:__
# - `viewpos: vec4`
# - `lightpos: vec4`
# - `time: float`
# - `time2: float`
# @details __Output variables:__
# - `waterTex0: vec4` lightpos
# - `waterTex1: vec4` moving texcoords
# - `waterTex2: vec4` moving texcoord
# - `waterTex3: vec4` for projection
# - `waterTex4: vec4` viewts


##
# @authors Romain GUYOT de la HARDROUYERE
# @authors Matthieu BOURNAT
# @authors Antoine CHESNEAU
# @class WaterVertex
# @brief This shader will create a water effect on a water plane
# @version 1.0
# @date 2014-01-07
# @shadertype Vertex Shader
# @details This is the vertex-part of the shader water
# @details __Input variables:__
# - `viewpos: vec4`
# - `lightpos: vec4`
# - `time: float`
# - `time2: float`
# @details __Output variables:__
# - `waterTex0: vec4` lightpos
# - `waterTex1: vec4` moving texcoords
# - `waterTex2: vec4` moving texcoord
# - `waterTex3: vec4` for projection
# - `waterTex4: vec4` viewts

class WaterVertex(Shader):

	## @fn __init__(self)
	# @brief Initialize this shader
	def __init__(self):
		Shader.__init__(self, ShaderType.PIXEL_SHADER)
		self.inVars['viewpos'] = Var('viewpos', self, VarType.IN,'vec4')
		self.inVars['lightpos'] = Var('lightpos', self, VarType.IN,'vec4')
		self.inVars['time'] = Var('time', self, VarType.IN,'float')
		self.inVars['time2'] = Var('time2', self, VarType.IN,'float')
		self.outVars['waterTex0'] = Var('waterTex0', self, VarType.OUT,'vec4')
		self.outVars['waterTex1'] = Var('waterTex1', self, VarType.OUT,'vec4')
		self.outVars['waterTex2'] = Var('waterTex2', self, VarType.OUT,'vec4')
		self.outVars['waterTex3'] = Var('waterTex3', self, VarType.OUT,'vec4')
		self.outVars['waterTex4'] = Var('waterTex4', self, VarType.OUT,'vec4')
		self.name = 'WaterVertex'
