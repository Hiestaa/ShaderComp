from ..core.Shader import *
from ..core import ShaderType
##
# @authors Romain GUYOT de la HARDROUYERE
# @authors Matthieu BOURNAT
# @authors Antoine CHESNEAU
# @package shaderComp.shaders.WaterFragment
# @brief This shader will create a water effect on a water plane
# @version 1.0
# @date 2014-01-07
# @shadertype Fragment Shader
# @details This is the fragment-part of the shader water
# @details __Input variables:__
# - `tex0: sampler2D`
# - `water_reflection: sampler2D`
# - `water_refraction: sampler2D`
# - `dudvmap: sampler2D`
# - `water_depthmap: sampler2D`
# - `waterColor: vec4`
# - `waterTex0: vec4` lightpos
# - `waterTex1: vec4` moving texcoords
# - `waterTex2: vec4` moving texcoord
# - `waterTex3: vec4` for projection
# - `waterTex4: vec4` viewts
# @details __Output variables:__
# - `color: vec4` the resulting color after applying the water effect


##
# @authors Romain GUYOT de la HARDROUYERE
# @authors Matthieu BOURNAT
# @authors Antoine CHESNEAU
# @class WaterFragment
# @brief This shader will create a water effect on a water plane
# @version 1.0
# @date 2014-01-07
# @shadertype Fragment Shader
# @details This is the fragment-part of the shader water
# @details __Input variables:__
# - `tex0: sampler2D`
# - `water_reflection: sampler2D`
# - `water_refraction: sampler2D`
# - `dudvmap: sampler2D`
# - `water_depthmap: sampler2D`
# - `waterColor: vec4`
# - `waterTex0: vec4` lightpos
# - `waterTex1: vec4` moving texcoords
# - `waterTex2: vec4` moving texcoord
# - `waterTex3: vec4` for projection
# - `waterTex4: vec4` viewts
# @details __Output variables:__
# - `color: vec4` the resulting color after applying the water effect
class WaterFragment(Shader):

	## @fn __init__(self)
	# @brief Initialize this shader
	def __init__(self):
		Shader.__init__(self, ShaderType.PIXEL_SHADER)
		self.inVars['tex0'] = Var('tex0', self, VarType.IN,'sampler2D')
		self.inVars['water_reflection'] = Var('water_reflection', self, VarType.IN,'sampler2D')
		self.inVars['water_refraction'] = Var('water_refraction', self, VarType.IN,'sampler2D')
		self.inVars['dudvmap'] = Var('dudvmap', self, VarType.IN,'sampler2D')
		self.inVars['water_depthmap'] = Var('water_depthmap', self, VarType.IN,'sampler2D')
		self.inVars['waterColor'] = Var('waterColor', self, VarType.IN,'vec4')
		self.inVars['waterTex0'] = Var('waterTex0', self, VarType.IN,'vec4')
		self.inVars['waterTex1'] = Var('waterTex1', self, VarType.IN,'vec4')
		self.inVars['waterTex2'] = Var('waterTex2', self, VarType.IN,'vec4')
		self.inVars['waterTex3'] = Var('waterTex3', self, VarType.IN,'vec4')
		self.inVars['waterTex4'] = Var('waterTex4', self, VarType.IN,'vec4')
		self.outVars['color'] = Var('color', self, VarType.OUT,'vec4')
		self.name = 'WaterFragment'
