##
# \authors Romain GUYOT de la HARDROUYERE
# \authors Matthieu BOURNAT
# \authors Antoine CHESNEAU
# \package shaderComp.printers.WaterFragment
# \brief This package contains the generators of the shader `WaterFragment`
# \version 0.1
# \date 2013-11-07
__all__ = ["WaterFragmentGLSLPrinter"]