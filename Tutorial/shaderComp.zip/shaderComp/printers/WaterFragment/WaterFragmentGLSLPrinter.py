
class Gen:

	def __init__(self, params):
		self.inVars, self.outVars = params

	def compute(self, printer) :
		# sca = printer.getRandomName('sca')
		# sca2 = printer.getRandomName('sca2')
		# tscale = printer.getRandomName('tscale')
		# two = printer.getRandomName('two')
		# mone = printer.getRandomName('mone')
		# ofive = printer.getRandomName('ofive')
		# exponent = printer.getRandomName('exponent')

		# lightTS = printer.getRandomName('lightTS')
		# viewt = printer.getRandomName('viewt')
		# disdis = printer.getRandomName('disdis')
		# dist = printer.getRandomName('dist')
		# fdist = printer.getRandomName('fdist')
		# nmap = printer.getRandomName('nmap')
		# vNorm = printer.getRandomName('vNorm')
		# tmp = printer.getRandomName('tmp')
		# temp = printer.getRandomName('temp')
		# projCoord = printer.getRandomName('projCoord')

		# refTex = printer.getRandomName('refTex')
		# refl = printer.getRandomName('refl')
		# refr = printer.getRandomName('refr')
		# wdepth = printer.getRandomName('wdepth')
		# vRef = printer.getRandomName('vRef')
		# stemp = printer.getRandomName('stemp')
		# specular = printer.getRandomName('specular')
		# invfres = printer.getRandomName('invfres')
		# fres = printer.getRandomName('fres')
		buffer = '''

	const vec4 sca = vec4(0.005, 0.005, 0.005, 0.005);
	const vec4 sca2 = vec4(0.02, 0.02, 0.02, 0.02);
	const vec4 tscale = vec4(0.25, 0.25, 0.25, 0.25);
	const vec4 two = vec4(2.0, 2.0, 2.0, 1.0);
	const vec4 mone = vec4(-1.0, -1.0, -1.0, 1.0);
	const vec4 ofive = vec4(0.5,0.5,0.5,1.0);

	const float exponent = 64.0;

	vec4 lightTS = normalize(''' + self.inVars['waterTex'].val + '''0);
	vec4 viewt = normalize(''' + self.inVars['waterTex'].val + '''4);
	vec4 disdis = texture2D(''' + self.inVars['dudvmap'].val + ''', vec2(''' + self.inVars['waterTex'].val + '''2 * tscale));
	vec4 dist = texture2D(''' + self.inVars['dudvmap'].val + ''', vec2(''' + self.inVars['waterTex'].val + '''1 + disdis*sca2));
	vec4 fdist = dist;
	fdist = fdist * two + mone;
	fdist = normalize(fdist);
	fdist *= sca;

	//load normalmap
	vec4 nmap = texture2D(''' + self.inVars['tex0'].val + ''', vec2(''' + self.inVars['waterTex'].val + '''1 + disdis*sca2));
	nmap = (nmap-ofive) * two;
	vec4 vNorm = nmap;
	vNorm = normalize(nmap);

	//get projective texcoords
	vec4 tmp = vec4(1.0 / ''' + self.inVars['waterTex'].val + '''3.w);
	vec4 temp = tmp;

	vec4 projCoord = ''' + self.inVars['waterTex'].val + '''3 * tmp;
	projCoord += vec4(1.0);
	projCoord *= vec4(0.5);
	tmp = projCoord + fdist;
	tmp = clamp(tmp, 0.001, 0.999);

	//load reflection,refraction and depth texture
	vec4 refTex = texture2D(''' + self.inVars['water_reflection'].val + ''', vec2(tmp));
	vec4 refl = refTex;
	vec4 refr = texture2D(''' + self.inVars['water_refraction'].val + ''', vec2(tmp));
	vec4 wdepth = texture2D(''' + self.inVars['water_depthmap'].val + ''', vec2(tmp));

	wdepth = vec4(pow(wdepth.x, 4.0));
	vec4 invdepth = 1.0 - wdepth;

	//calculate specular highlight
	vec4 vRef = normalize(reflect(-lightTS, vNorm));
	float stemp =max(0.0, dot(viewt, vRef) );
	stemp = pow(stemp, exponent);
	vec4 specular = vec4(stemp);

	//calculate fresnel and inverted fresnel
	vec4 invfres = vec4( dot(vNorm, viewt) );
	vec4 fres = vec4(1.0) -invfres ;

	//calculate reflection and refraction
	refr *= invfres;
	refr *= invdepth;
	temp = ''' + self.inVars['waterColor'].val + ''' * wdepth * invfres;
	refr += temp;
	refl *= fres;

	//add reflection and refraction
	tmp = refr + refl;

	''' self.outVars['color'].val + ''' = tmp + specular;
	}

'''
		buffer = buffer + '\n'
		return buffer
