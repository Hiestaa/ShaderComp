##
# \authors Romain GUYOT de la HARDROUYERE
# \authors Matthieu BOURNAT
# \authors Antoine CHESNEAU
# \package shaderComp.printers.math
# \brief This package contains the class needed to print the code source of the low level math shaders
# \version 0.1
# \date 2013-11-08
__all__ = []