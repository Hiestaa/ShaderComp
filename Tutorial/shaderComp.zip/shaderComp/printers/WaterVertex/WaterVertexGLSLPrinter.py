
class Gen:

	def __init__(self, params):
		self.inVars, self.outVars = params

	def compute(self, printer) :

		buffer = '''
	void main(void)
	{
	vec4 mpos, temp;
	vec4 tangent = vec4(1.0, 0.0, 0.0, 0.0);
	vec4 norm = vec4(0.0, 1.0, 0.0, 0.0);
	vec4 binormal = vec4(0.0, 0.0, 1.0, 0.0);

	mpos = gl_ModelViewMatrix * gl_Vertex;

	temp = ''' + self.inVars['viewpos'].val + ''' - mpos;
	''' + self.outVars[waterTex4].val + '''.x = dot(temp, tangent);
	''' + self.outVars[waterTex4].val + '''.y = dot(temp, binormal);
	''' + self.outVars[waterTex4].val + '''.z = dot(temp, norm);
	''' + self.outVars[waterTex4].val + '''.w = 0.0;

	temp = ''' + self.inVars['lightpos'].val + ''' - mpos;
	''' + self.outVars[waterTex0].val + '''.x = dot(temp, tangent);
	''' + self.outVars[waterTex0].val + '''.y = dot(temp, binormal);
	''' + self.outVars[waterTex0].val + '''.z = dot(temp, norm);
	''' + self.outVars[waterTex0].val + '''.w = 0.0;

	mpos = gl_ProjectionMatrix * mpos;

	vec4 t1 = vec4(0.0, -''' + self.inVars['time'].val + ''', 0.0,0.0);
	vec4 t2 = vec4(0.0, -''' + self.inVars['time2'].val + ''', 0.0,0.0);

	''' + self.outVars[waterTex1].val + ''' = gl_MultiTexCoord0 + t1;
	''' + self.outVars[waterTex2].val + ''' = gl_MultiTexCoord0 + t2;

	''' + self.outVars[waterTex3].val + ''' = mpos;

	gl_Position = mpos;
	}

'''
		buffer = buffer + '\n'
		return buffer
