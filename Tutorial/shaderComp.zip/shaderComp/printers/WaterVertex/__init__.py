##
# \authors Romain GUYOT de la HARDROUYERE
# \authors Matthieu BOURNAT
# \authors Antoine CHESNEAU
# \package shaderComp.printers.WaterVertex
# \brief This package contains the generators of the shader `WaterVertex`
# \version 0.1
# \date 2013-11-07
__all__ = ["WaterVertexGLSLPrinter"]