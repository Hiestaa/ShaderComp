##
# \authors Romain GUYOT de la HARDROUYERE
# \authors Matthieu BOURNAT
# \authors Antoine CHESNEAU
# \package shaderComp.printers.DefaultVertexShader
# \brief This package contains the generators of the shader `DefaultVertexShader`
# \version 0.1
# \date 2013-11-07
__all__ = ["DefaultVertexShaderGLSLPrinter"]