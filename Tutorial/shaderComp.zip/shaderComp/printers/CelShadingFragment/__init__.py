##
# \authors Romain GUYOT de la HARDROUYERE
# \authors Matthieu BOURNAT
# \authors Antoine CHESNEAU
# \package shaderComp.printers.CelShadingFragment
# \brief This package contains the generators of the shader `CelShadingFragment`
# \version 0.1
# \date 2013-11-07
__all__ = ["CelShadingFragmentGLSLPrinter"]